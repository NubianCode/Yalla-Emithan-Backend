<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SchoolSupervisorType extends Model
{
    public $timestamps = false;
	protected $guarded = [];
    protected $table = "schools_supervisors_types";


    
}