<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassSubject extends Model
{
    public $timestamps = false;
	protected $guarded = [];
    protected $table = "classes_subjects";
    
}