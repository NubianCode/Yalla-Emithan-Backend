<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SchoolStudentType extends Model
{
    public $timestamps = false;
	protected $guarded = [];
    protected $table = "schools_students_types";
    
}