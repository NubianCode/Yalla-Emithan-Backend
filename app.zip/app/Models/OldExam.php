<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OldExam extends Model
{
    public $timestamps = false;
	protected $guarded = [];
    protected $table = "old_exams";


    
}