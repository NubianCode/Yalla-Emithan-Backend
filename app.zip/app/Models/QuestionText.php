<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionText extends Model
{
    public $timestamps = false;
	protected $guarded = [];
    protected $table = "questions_texts";

    
}