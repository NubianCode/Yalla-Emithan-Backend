<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeworkStatus extends Model
{
    public $timestamps = false;
	protected $guarded = [];
    protected $table = "homeworks_status";
    
}